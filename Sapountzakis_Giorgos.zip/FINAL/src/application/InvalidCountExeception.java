package application;

class InvalidCountExeception extends Exception {
}
