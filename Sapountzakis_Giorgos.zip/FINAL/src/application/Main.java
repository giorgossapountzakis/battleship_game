package application;

import java.util.Scanner;
import java.awt.Desktop.Action;
import java.awt.event.InputEvent;
import java.io.*;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.VPos;
import javafx.event.ActionEvent;
import javafx.scene.control.*;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.*;
import javafx.scene.input.MouseEvent;
import java.util.concurrent.TimeUnit;


public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {
			primaryStage.setTitle("MediaLab Battleship");
			GridPane grid = new GridPane();
			grid.setVgap(5);
			grid.setHgap(5);
			Scene scene = new Scene(grid, 1000, 440);// mexri 700 to deytero allios den to xoraei h o8onh
														
			primaryStage.setScene(scene);
			primaryStage.setMaxHeight(480); 
			primaryStage.show();
			

			MenuBar menuBar = new MenuBar();
			VBox menuVBox = new VBox(menuBar);
			Menu menu1 = new Menu("Application");
			MenuItem menuItem1 = new MenuItem("Start");
			MenuItem menuItem2 = new MenuItem("Load");
			MenuItem menuItem3 = new MenuItem("Exit");

			SeparatorMenuItem separator1 = new SeparatorMenuItem();
			SeparatorMenuItem separator2 = new SeparatorMenuItem();
			menu1.getItems().add(menuItem1);
			menu1.getItems().add(separator1);
			menu1.getItems().add(menuItem2);
			menu1.getItems().add(separator2);
			menu1.getItems().add(menuItem3);
			Menu menu2 = new Menu("Details");
			MenuItem menuItem4 = new MenuItem("Enemy Ships");
			MenuItem menuItem5 = new MenuItem("Player Shots");
			MenuItem menuItem6 = new MenuItem("Enemy Shots");
			SeparatorMenuItem separator3 = new SeparatorMenuItem();
			SeparatorMenuItem separator4 = new SeparatorMenuItem();
			menu2.getItems().add(menuItem4);
			menu2.getItems().add(separator3);
			menu2.getItems().add(menuItem5);
			menu2.getItems().add(separator4);
			menu2.getItems().add(menuItem6);
			menuBar.getMenus().add(menu1);
			menuBar.getMenus().add(menu2);
			grid.add(menuVBox, 0, 0);
			
			Start start = new Start();
			menuItem1.setOnAction(new EventHandler<ActionEvent>() {
				@Override
				public void handle(ActionEvent e) {
					
					if (start.getpressedload() == true) {
						System.out.println("Start Clicked");

// START

						int whostarts =start.getRandomNumber(0, 1000);

						Stage popupstage = new Stage();
						BorderPane popuppane = new BorderPane();
						if (whostarts <= 500) {
							Text text13 = new Text(
									"If you did not see any error messages YOU can start ,otherwise please fix the scenario and load-start again");
							text13.setFont(Font.font("Verdana", 20));
							text13.setFill(Color.ORANGE);
							popuppane.setCenter(text13);
						} else {
							Text text13 = new Text(
									"If you did not see any error messages it means the COMPUTER has already started playing and it's your turn, otherwise please fix the scenario and load-start again");
							text13.setFont(Font.font("Verdana", 15));
							text13.setFill(Color.RED);
							popuppane.setCenter(text13);
						}
						Scene popupscene = new Scene(popuppane, 1200, 300);
						popupstage.setScene(popupscene);
						popupstage.show();

						GridPane myboard = new GridPane();
						start.createmyboard(myboard);
						grid.add(myboard, 0, 6);
						grid.add(new Text("My shot Board"), 2, 5);
						GridPane myshotboard = new GridPane();
						start.createmyshotboard(myshotboard);
						grid.add(new Text(" "), 1, 6);
						grid.add(myshotboard, 2, 6);

						GridPane enemyboard = new GridPane();
						start.createenemyboard(enemyboard);

						grid.add(enemyboard, 0, 9);
						// grid.add(new Text(" "), 0, 9);

						grid.add(new Text(" "), 1, 7);
						HBox attackHBox = new HBox();
						Label label1 = new Label("ATTACK (type RowCol and press enter)");
						TextField textField = new TextField();

						attackHBox.getChildren().addAll(label1, textField);
						grid.add(attackHBox, 0, 8);

						// READFILES

						File f = new File("medialab/player_SCENARIO-" + start.getID() + ".txt"); // Creation of File
																									// Descriptor for
						File enef = new File("medialab/enemy_SCENARIO-" + start.getID() + ".txt"); // Creation of File
																									// Descriptor
						Ship[] myship = new Ship[5];
						Ship[] enemyship = new Ship[5];
						FileReader fr;
						FileReader enefr;
//EXCEPTIONS			
						boolean flag1= true;
						boolean flag2= true;
						boolean flag3= true;
						boolean flag4=true;
						
						try {

							fr = new FileReader(f);
							start.readmyships(f, fr, myship);
							try {
								for (int i = 0; i < 5; i++)start.readmyships(f, fr, myship)[i].isoutoftable();
							} catch (OversizeException myoversizeexception) {
								flag1=false;
								System.out.println("OversizeException me");
								Stage popupstage1 = new Stage();
								BorderPane popuppane1 = new BorderPane();
								Text text14 = new Text("At least one of your ships are out of the table bounds");
								text14.setFont(Font.font("Verdana", 20));
								text14.setFill(Color.ORANGE);
								popuppane1.setCenter(text14);
								Scene popupscene1 = new Scene(popuppane1, 800, 300);
								popupstage1.setScene(popupscene1);
								popupstage1.show();
							}
							enefr = new FileReader(enef);
							start.readenemyships(enef, enefr, enemyship);
							try {
								for (int i = 0; i < 5; i++)start.readenemyships(enef, enefr, enemyship)[i].isoutoftable();
							} catch (OversizeException enemyoversizeexception) {
								flag1=false;
								System.out.println("OversizeException computer");
								Stage popupstage2 = new Stage();
								BorderPane popuppane2 = new BorderPane();
								Text text14 = new Text("At least one of computer's ships are out of the table bounds");
								text14.setFont(Font.font("Verdana", 20));
								text14.setFill(Color.RED);
								popuppane2.setCenter(text14);
								Scene popupscene2 = new Scene(popuppane2, 800, 300);
								popupstage2.setScene(popupscene2);
								popupstage2.show();
							}
							if(flag1==true){
							try {
								start.typecheck(myship);
							} catch (InvalidCountExeception myinvalid) {
								flag2=false;
								System.out.println("InvalidCountExeception me");
								Stage popupstage2 = new Stage();
								BorderPane popuppane2 = new BorderPane();
								Text text14 = new Text("You have at least two ships of the same type");
								text14.setFont(Font.font("Verdana", 30));
								text14.setFill(Color.ORANGE);
								popuppane2.setCenter(text14);
								Scene popupscene2 = new Scene(popuppane2, 800, 300);
								popupstage2.setScene(popupscene2);
								popupstage2.show();
							}
						

							try {
								start.typecheck(enemyship);
							} catch (InvalidCountExeception enemyinvalid) {
								flag2=false;
								System.out.println("InvalidCountExeception computer");
								Stage popupstage2 = new Stage();
								BorderPane popuppane2 = new BorderPane();
								Text text14 = new Text("Computer has at least two ships of the same type");
								text14.setFont(Font.font("Verdana", 30));
								text14.setFill(Color.RED);
								popuppane2.setCenter(text14);
								Scene popupscene2 = new Scene(popuppane2, 800, 300);
								popupstage2.setScene(popupscene2);
								popupstage2.show();
							}
						}

						} catch (IOException e1) {
						}

// DEPLOY SHIPS
						int[] myhelparray = start.mydeploy(myboard, myship);
						

						int[] enemyhelparray = start.enemydeploy(enemyboard, enemyship);
						
						if(flag1==true && flag2==true) {
						try {
							start.sameplacecheck(myhelparray);
						} catch (OverlapTilesException myoverlap) {
							flag3=false;
							System.out.println("OverlapTilesException me");
							Stage popupstage2 = new Stage();
							BorderPane popuppane2 = new BorderPane();
							Text text14 = new Text("You have at least two ships overlapping");
							text14.setFont(Font.font("Verdana", 30));
							text14.setFill(Color.ORANGE);
							popuppane2.setCenter(text14);
							Scene popupscene2 = new Scene(popuppane2, 800, 300);
							popupstage2.setScene(popupscene2);
							popupstage2.show();
						}
						try {
							start.sameplacecheck(enemyhelparray);
						} catch (OverlapTilesException enemyoverlap) {
							flag3=false;
							System.out.println("OverlapTilesException computer");
							Stage popupstage2 = new Stage();
							BorderPane popuppane2 = new BorderPane();
							Text text14 = new Text("Computer has at least two ships overlapping");
							text14.setFont(Font.font("Verdana", 30));
							text14.setFill(Color.RED);
							popuppane2.setCenter(text14);
							Scene popupscene2 = new Scene(popuppane2, 800, 300);
							popupstage2.setScene(popupscene2);
							popupstage2.show();
						}
						}
						if(flag1==true&&flag2==true&&flag3==true) {
						try {
							start.tancheck(myhelparray);
						} catch (AdjacentTilesException myadjacent) {
							flag4=false;
							System.out.println("AdjacentTilesException me");
							Stage popupstage2 = new Stage();
							BorderPane popuppane2 = new BorderPane();
							Text text14 = new Text("You have at least two ships with adjacent tiles");
							text14.setFont(Font.font("Verdana", 30));
							text14.setFill(Color.ORANGE);
							popuppane2.setCenter(text14);
							Scene popupscene2 = new Scene(popuppane2, 800, 300);
							popupstage2.setScene(popupscene2);
							popupstage2.show();
						}
						try {
							start.tancheck(enemyhelparray);
						} catch (AdjacentTilesException enemyadjacent) {
							flag4=false;
							System.out.println("AdjacentTilesException computer");
							Stage popupstage2 = new Stage();
							BorderPane popuppane2 = new BorderPane();
							Text text14 = new Text("Computer has at least two ships with adjacent tiles");
							text14.setFont(Font.font("Verdana", 30));
							text14.setFill(Color.RED);
							popuppane2.setCenter(text14);
							Scene popupscene2 = new Scene(popuppane2, 800, 300);
							popupstage2.setScene(popupscene2);
							popupstage2.show();
						}
						}

// GAME ON
						if(flag1==true&&flag2==true&&flag3==true&&flag4==true){
						Player me = new Player(myship);
						Player computer = new Player(enemyship);
						// System.out.println(me.getlastfiveshots());

						textField.setOnAction(new EventHandler<ActionEvent>() {
							@Override
							public void handle(ActionEvent e) {
								int randrow1=0;
								int randcol1=0;
								if (whostarts > 500 &&me.getfirsttime()==true ) {
									randrow1 = start.getRandomNumber(0, 9);
									randcol1 = start.getRandomNumber(0, 9);
									Shot enemyshot1 = new Shot(randrow1, randcol1);
									computer.setshotsnumber();
									//myhelparray[20+10*randrow1+randcol1]=10;
									if(myhelparray[20+10*randrow1+randcol1]==0 ||myhelparray[20+10*randrow1+randcol1]==10)myhelparray[20+10*randrow1+randcol1]=10;
									else myhelparray[20+10*randrow1+randcol1]=11;
									//for (int i = 0; i < 120; i++) {if (i % 10 ==0)System.out.println();System.out.print(myhelparray[i]);}
									
									int enemyshotType1 = enemyshot1.enemyshotresultTYPE(myboard);
									int enemy1points = enemyshot1.enemyshotresult(myboard, myship);
									computer.setlastfiveshots(enemyshot1, enemyshotType1);
									computer.setpoints(enemy1points);
									if (enemy1points != 0) {
										computer.setsuccessfull();
									}
									me.setfirsttime();
								}
								System.out.println("Coordinates read");
								int value = Integer.parseInt(textField.getText());
								textField.clear();
								int row = value / 10;
								int col = value % 10;
								Shot myshot = new Shot(row, col);
								me.setshotsnumber();
								
								enemyhelparray[20+10*randrow1+randcol1]=10;
								if(enemyhelparray[20+10*randrow1+randcol1]==0||myhelparray[20+10*randrow1+randcol1]==10)enemyhelparray[20+10*randrow1+randcol1]=10;
								else enemyhelparray[20+10*randrow1+randcol1]=11;
								/*System.out.println();
								for (int i = 0; i < 120; i++) {if (i % 10 ==
								0)System.out.println();System.out.print(enemyhelparray[i]);}
								System.out.println();
								*/
								
								int myshotType = myshot.myshotresultTYPE(enemyboard);
								int mypoints = myshot.myshotresult(enemyboard, enemyship, myshotboard);
								me.setlastfiveshots(myshot, myshotType);
								me.setpoints(mypoints);
								if (mypoints != 0) {
									me.setsuccessfull();
								}
								if ((computer.getshotsnumber() >= 40 && me.getshotsnumber() >= 40)
										|| computer.aliveships() == 0 || me.aliveships() == 0) {
									me.setflag5();
									start.finish(me, computer);
								}
								
								int randrow = start.getRandomNumber(0, 9);
								int randcol = start.getRandomNumber(0, 9);
								int calculatedrow=0;
								int calculatedcol=0;
								if(computer.getshotsnumber()==0) {
									calculatedrow=randrow;
									calculatedcol=randcol;
								}
								else if(computer.getshotsnumber()==1){
									calculatedrow=randrow1;
									if(randcol1==1) {calculatedcol=randcol1+1;}
									else if(randcol1==9) {calculatedcol=randcol1-1;}
									else{calculatedcol=randcol1+1;}
								}
								else{//tote taktikh 
									int x=computer.tactic(start,myhelparray);
									calculatedrow = x/10;
									calculatedcol = x%10;
									}
								
								Shot enemyshot = new Shot(calculatedrow, calculatedcol);
								computer.setshotsnumber();
								
								if(myhelparray[20+10*calculatedrow+calculatedcol]==0)myhelparray[20+10*calculatedrow+calculatedcol]=10;
								else myhelparray[20+10*calculatedrow+calculatedcol]=11;
								
								if(me.getflag5()==true ) {
								int enemyshotType = enemyshot.enemyshotresultTYPE(myboard);
								int enemypoints = enemyshot.enemyshotresult(myboard, myship);
								computer.setlastfiveshots(enemyshot, enemyshotType);
								computer.setpoints(enemypoints);
								if (enemypoints != 0) {
									computer.setsuccessfull();
								}

								if ((computer.getshotsnumber() >= 40 && me.getshotsnumber() >= 40)
										|| computer.aliveships() == 0 || me.aliveships() == 0) {
									start.finish(me, computer);
								}
								}
								// ananeono tin diepafh to pano meros
								start.change(grid, 7, me.aliveships());
								start.change(grid, 8, me.getpoints());
								double mysuccessrate = me.getsuccessfull() / me.getshotsnumber();
								start.change(grid, 9, mysuccessrate);
								start.change(grid, 10, computer.aliveships());
								start.change(grid, 11, computer.getpoints());
								double enemysuccessrate = computer.getsuccessfull() / computer.getshotsnumber();
								start.change(grid, 12, enemysuccessrate);

							}

						});

						menuItem4.setOnAction(new EventHandler<ActionEvent>() {
							@Override
							public void handle(ActionEvent e) {
								System.out.println("Enemy Ships Clicked");
								Stage popupstage = new Stage();
								popupstage.setTitle("Enemy Ships Window");
								GridPane popuppane = new GridPane();
								int data = computer.aliveships();
								Text[] popuptext = new Text[6];
								popuptext[5] = new Text("Enemy ships alive = " + String.valueOf(data));
								popuptext[5].setFont(Font.font("Verdana", 25));
								popuptext[5].setFill(Color.RED);
								popuppane.add(popuptext[5], 0, 0);
								for (int i = 0; i < 5; i++) {
									int shiptype = enemyship[i].gettype();
									boolean shipstatus = enemyship[i].getsunken();
									if (shiptype == 1 && shipstatus == true)
										popuptext[i] = new Text("Enemy Carrier is DEAD");
									else if (shiptype == 1 && shipstatus == false)
										popuptext[i] = new Text("Enemy Carrier is ALIVE");
									else if (shiptype == 2 && shipstatus == true)
										popuptext[i] = new Text("Enemy Battleship is DEAD");
									else if (shiptype == 2 && shipstatus == false)
										popuptext[i] = new Text("Enemy Battleship is ALIVE");
									else if (shiptype == 3 && shipstatus == true)
										popuptext[i] = new Text("Enemy Cruiser is DEAD");
									else if (shiptype == 3 && shipstatus == false)
										popuptext[i] = new Text("Enemy Cruiser is ALIVE");
									else if (shiptype == 4 && shipstatus == true)
										popuptext[i] = new Text("Enemy Submarine is DEAD");
									else if (shiptype == 4 && shipstatus == false)
										popuptext[i] = new Text("Enemy Submarine is ALIVE");
									else if (shiptype == 5 && shipstatus == true)
										popuptext[i] = new Text("Enemy Destroyer is DEAD");
									else if (shiptype == 5 && shipstatus == false)
										popuptext[i] = new Text("Enemy Destroyer is ALIVE");
									popuptext[i].setFont(Font.font("Verdana", 25));
									popuptext[i].setFill(Color.RED);
									popuppane.add(popuptext[i], 0, i + 1);
								}

								Scene popupscene = new Scene(popuppane, 800, 400);
								popupstage.setScene(popupscene);
								popupstage.show();
							}
						});

						menuItem5.setOnAction(new EventHandler<ActionEvent>() {
							@Override
							public void handle(ActionEvent e) {
								System.out.println("Player Shots Clicked");
								Stage popupstage = new Stage();
								popupstage.setTitle("Player Shots Window");
								GridPane popuppane = new GridPane();
								Text[] popuptext = new Text[5];
								for (int i = 0; i < 5; i++) {
									int[] data = new int[3];
									data[0] = me.getlastfiveshots()[i][0];// 00
									data[1] = me.getlastfiveshots()[i][1];// 01
									data[2] = me.getlastfiveshots()[i][2];// 02
									if (data[2] != 0)
										popuptext[i] = new Text("Target Coordinates (row,col) = " + data[0] + ","
												+ data[1] + " Shot successfull , hit ship type " + data[2]);
									else if (data[2] == 0)
										popuptext[i] = new Text("Target Coordinates (row,col) = " + data[0] + ","
												+ data[1] + " Shot unsuccessfull");
									popuptext[i].setFont(Font.font("Verdana", 25));
									popuptext[i].setFill(Color.ORANGE);
									popuppane.add(popuptext[i], 0, i + 1);
								}
								Scene popupscene = new Scene(popuppane, 1000, 400);
								popupstage.setScene(popupscene);
								popupstage.show();
								// System.out.println(me.getlastfiveshots()[0][0]);
							}
						});

						menuItem6.setOnAction(new EventHandler<ActionEvent>() {
							@Override
							public void handle(ActionEvent e) {
								System.out.println("Enemy Shots Clicked");
								Stage popupstage = new Stage();
								popupstage.setTitle("Enemy Shots Window");
								GridPane popuppane = new GridPane();
								Text[] popuptext = new Text[5];
								for (int i = 0; i < 5; i++) {
									int[] data = new int[3];
									data[0] = computer.getlastfiveshots()[i][0];// 00
									data[1] = computer.getlastfiveshots()[i][1];// 01
									data[2] = computer.getlastfiveshots()[i][2];// 02
									if (data[2] != 0)
										popuptext[i] = new Text("Target Coordinates (row,col) = " + data[0] + ","
												+ data[1] + " Shot successfull , hit ship type " + data[2]);
									else if (data[2] == 0)
										popuptext[i] = new Text("Target Coordinates (row,col) = " + data[0] + ","
												+ data[1] + " Shot unsuccessfull");
									popuptext[i].setFont(Font.font("Verdana", 25));
									popuptext[i].setFill(Color.RED);
									popuppane.add(popuptext[i], 0, i + 1);
								}
								Scene popupscene = new Scene(popuppane, 1000, 400);
								popupstage.setScene(popupscene);
								popupstage.show();
							}
						});

					}
				}
}
			});

			menuItem2.setOnAction(new EventHandler<ActionEvent>() {
				@Override
				public void handle(ActionEvent e) {
					System.out.println("Load Clicked");
					start.setpressedload();
					Stage popupstage = new Stage();
					popupstage.setTitle("Load Window");
					BorderPane popuppane = new BorderPane();
					HBox insertHBox = new HBox();
					Label label2 = new Label("Insert Scenario-ID here : ");
					label2.setFont(Font.font("Verdana", 15));
					TextField textField1 = new TextField();
					insertHBox.getChildren().addAll(label2, textField1);
					Text loadtext=new Text("type Scenario's number,press enter and then start to play the game");
					loadtext.setFont(Font.font("Verdana", 17));
					loadtext.setFill(Color.ORANGE);
					popuppane.setCenter(insertHBox);
					popuppane.setTop(loadtext);
					Scene popupscene = new Scene(popuppane, 600, 200);
					popupstage.setScene(popupscene);
					popupstage.show();

					
					
					
					textField1.setOnAction(new EventHandler<ActionEvent>() {
						@Override
						public void handle(ActionEvent e) {
							int x = Integer.parseInt(textField1.getText());
							start.setID(x);
							System.out.println("Scenario " + start.getID());
							start.change(grid, 7, "my alive ships");
							start.change(grid, 8, "my total points");
							start.change(grid, 9, "my shot success rate");
							start.change(grid, 10, "enemy alive ships");
							start.change(grid, 11, "enemy total points");
							start.change(grid, 12, "my shot success rate");
							popupstage.close();
						}
					});

				}
			});

			menuItem3.setOnAction(new EventHandler<ActionEvent>() {
				@Override
				public void handle(ActionEvent e) {
					System.out.println("Exit Clicked");
					System.exit(0);
				}
			});

			VBox vBox0 = new VBox();
			Text text0 = new Text(" ");
			text0.setFont(Font.font("Verdana", 15));
			text0.setFill(Color.BLACK);
			vBox0.getChildren().add(text0);
			grid.add(vBox0, 0, 1);

			VBox vBox1 = new VBox();
			Text text1 = new Text("Alive Ships");
			text1.setFont(Font.font("Verdana", 15));
			text1.setFill(Color.BLACK);
			vBox1.getChildren().add(text1);
			grid.add(vBox1, 0, 2);

			// VBox vBox2 = new VBox();
			Text text2 = new Text("Total Points");
			text2.setFont(Font.font("Verdana", 15));
			text2.setFill(Color.BLACK);
			// vBox2.getChildren().add(text2);
			// grid.add(vBox2, 0, 3);
			grid.add(text2, 0, 3);

			VBox vBox3 = new VBox();
			Text text3 = new Text("Shot Success Rate");
			text3.setFont(Font.font("Verdana", 15));
			text3.setFill(Color.BLACK);
			vBox3.getChildren().add(text3);
			grid.add(vBox3, 0, 4);

			VBox vBox4 = new VBox();
			Text text4 = new Text("Mine");
			text4.setFont(Font.font("Verdana", 15));
			text4.setFill(Color.BLACK);
			vBox4.getChildren().add(text4);
			grid.add(vBox4, 1, 1);

			VBox vBox11 = new VBox();
			Text text11 = new Text("Enemy's");
			text11.setFont(Font.font("Verdana", 15));
			text11.setFill(Color.BLACK);
			vBox11.getChildren().add(text11);
			grid.add(vBox11, 2, 1);

			VBox vBox5 = new VBox();
			Text text5 = new Text("my alive ships");
			text5.setFont(Font.font("Verdana", 15));
			text5.setFill(Color.ORANGE);
			vBox5.getChildren().add(text5);
			grid.add(vBox5, 1, 2);
			VBox vBox6 = new VBox();
			Text text6 = new Text("my total points");
			text6.setFont(Font.font("Verdana", 15));
			text6.setFill(Color.ORANGE);
			vBox6.getChildren().add(text6);
			grid.add(vBox6, 1, 3);
			VBox vBox7 = new VBox();
			Text text7 = new Text("my shot success rate");
			text7.setFont(Font.font("Verdana", 15));
			text7.setFill(Color.ORANGE);
			vBox7.getChildren().add(text7);
			grid.add(vBox7, 1, 4);

			VBox vBox8 = new VBox();
			Text text8 = new Text("enemy alive ships");
			text8.setFont(Font.font("Verdana", 15));
			text8.setFill(Color.RED);
			vBox8.getChildren().add(text8);
			grid.add(vBox8, 2, 2);
			VBox vBox9 = new VBox();
			Text text9 = new Text("enemy total points");
			text9.setFont(Font.font("Verdana", 15));
			text9.setFill(Color.RED);
			vBox9.getChildren().add(text9);
			grid.add(vBox9, 2, 3);
			VBox vBox10 = new VBox();
			Text text10 = new Text("enemy shot success rate");
			text10.setFont(Font.font("Verdana", 15));
			text10.setFill(Color.RED);
			vBox10.getChildren().add(text10);
			grid.add(vBox10, 2, 4);

			grid.add(new Text("My Board"), 0, 5);


		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		launch(args);
	}
}


