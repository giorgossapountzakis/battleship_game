package application;

import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

class Shot {
	private int shotrow;
	private int shotcol;
	// static int shotcounter = 1;
	private boolean success = false;

	public Shot(int row, int col) {
		shotrow = row;
		shotcol = col;
		// shotcounter++;
	}

	public boolean getsuccess() {
		return success;
	}

	public void setsuccess() {
		success = true;
	}

	public int getshotrow() {
		return shotrow;
	}

	public int getshotcol() {
		return shotcol;
	}

	// myship[0] einai typoy 1,myship 2 einai typoy 3, exo 5 antikeimena myship
	public int myshotresult(GridPane enemyboard, Ship[] enemyship, GridPane myshotboard) {// points kai allazei kai ta
																							// boards
		Rectangle attacked = new Rectangle();
		Rectangle attackednote = new Rectangle();
		int row = shotrow;
		int col = shotcol;
		attacked = (Rectangle) enemyboard.getChildren().get(21 + 10 * row + col);
		attackednote = (Rectangle) myshotboard.getChildren().get(21 + 10 * row + col);
		Color c = (Color) attacked.getFill();
		if (c == Color.CYAN) {
			// System.out.println("Den petyxes tipota");
			attacked.setStyle("-fx-fill: black; -fx-stroke: black; -fx-stroke-width: 1;");
			attackednote.setStyle("-fx-fill: black; -fx-stroke: black; -fx-stroke-width: 1;");
			return 0;
		} else if (c == Color.BLUE) {
			attacked.setStyle("-fx-fill: red; -fx-stroke: black; -fx-stroke-width: 1;");// red xtyphmeno ploio
			attackednote.setStyle("-fx-fill: red; -fx-stroke: black; -fx-stroke-width: 1;");
			int i = 0;
			while (enemyship[i].gettype() != 1) {
				i++;
			} // xtyph8hke to enemyship[i]
			enemyship[i].settimeshit();
			enemyship[i].setuntouched();
			enemyship[i].sethit();
			int pointsearned = 350;
			if (enemyship[i].gettimeshit() == 5) {// na ksanado edo to 5 and den doyleyei
				enemyship[i].setsunken();
				pointsearned += 1000;
			}
			return pointsearned;
		} else if (c == Color.GREY) {
			attacked.setStyle("-fx-fill: red; -fx-stroke: black; -fx-stroke-width: 1;");// red xtyphmeno ploio
			attackednote.setStyle("-fx-fill: red; -fx-stroke: black; -fx-stroke-width: 1;");
			int i = 0;
			while (enemyship[i].gettype() != 2) {
				i++;
			} // xtyph8hke to enemyship[i]
				// System.out.println(i);
			enemyship[i].settimeshit();
			enemyship[i].setuntouched();
			enemyship[i].sethit();
			int pointsearned = 250;
			if (enemyship[i].gettimeshit() == 4) {// na ksanado edo to 5 and den doyleyei
				System.out.println("geia soy");
				enemyship[i].setsunken();
				pointsearned += 500;
			}
			return pointsearned;
		} else if (c == Color.ORANGE) {
			attacked.setStyle("-fx-fill: red; -fx-stroke: black; -fx-stroke-width: 1;");// red xtyphmeno ploio
			attackednote.setStyle("-fx-fill: red; -fx-stroke: black; -fx-stroke-width: 1;");
			int i = 0;
			while (enemyship[i].gettype() != 3) {
				i++;
			} // xtyph8hke to enemyship[i]
			enemyship[i].settimeshit();
			enemyship[i].setuntouched();
			enemyship[i].sethit();
			int pointsearned = 100;
			if (enemyship[i].gettimeshit() == 3) {// na ksanado edo to 5 and den doyleyei
				enemyship[i].setsunken();
				pointsearned += 250;
			}
			return pointsearned;
		} else if (c == Color.YELLOW) {
			attacked.setStyle("-fx-fill: red; -fx-stroke: black; -fx-stroke-width: 1;");// red xtyphmeno ploio
			attackednote.setStyle("-fx-fill: red; -fx-stroke: black; -fx-stroke-width: 1;");
			int i = 0;
			while (enemyship[i].gettype() != 4) {
				i++;
			} // xtyph8hke to enemyship[i]
			enemyship[i].settimeshit();
			enemyship[i].setuntouched();
			enemyship[i].sethit();
			int pointsearned = 100;
			if (enemyship[i].gettimeshit() == 3) {// na ksanado edo to 5 and den doyleyei
				enemyship[i].setsunken();
				pointsearned += 0;
			}
			return pointsearned;
		} else if (c == Color.GREEN) {
			attacked.setStyle("-fx-fill: red; -fx-stroke: black; -fx-stroke-width: 1;");// red xtyphmeno ploio
			attackednote.setStyle("-fx-fill: red; -fx-stroke: black; -fx-stroke-width: 1;");
			int i = 0;
			while (enemyship[i].gettype() != 5) {
				i++;
			} // xtyph8hke to enemyship[i]
			enemyship[i].settimeshit();
			enemyship[i].setuntouched();
			enemyship[i].sethit();
			int pointsearned = 50;
			if (enemyship[i].gettimeshit() == 2) {// na ksanado edo to 5 and den doyleyei
				enemyship[i].setsunken();
				pointsearned += 0;
			}
			return pointsearned;
		} else if (c == Color.RED || c == Color.BLACK) {
			System.out.println("Exeis ksanarikei edo bre mpoumpouna ");
			return 0;
		} else {
			System.out.println("egine la8os");
			return 0;
		}

	}

	public int enemyshotresult(GridPane myboard, Ship[] myship) {// points kai allazei kai ta boards
		Rectangle attacked = new Rectangle();
		int row = shotrow;
		int col = shotcol;
		attacked = (Rectangle) myboard.getChildren().get(21 + 10 * row + col);
		Color c = (Color) attacked.getFill();
		if (c == Color.CYAN) {
			attacked.setStyle("-fx-fill: black; -fx-stroke: black; -fx-stroke-width: 1;");
			return 0;
		} else if (c == Color.BLUE) {
			attacked.setStyle("-fx-fill: red; -fx-stroke: black; -fx-stroke-width: 1;");// red xtyphmeno ploio
			int i = 0;
			while (myship[i].gettype() != 1) {
				i++;
			} // xtyph8hke to myship[i]
			myship[i].settimeshit();
			myship[i].setuntouched();
			myship[i].sethit();
			int pointsearned = 350;
			if (myship[i].gettimeshit() == 5) {// na ksanado edo to 5 and den doyleyei
				myship[i].setsunken();
				pointsearned += 1000;
			}
			return pointsearned;
		} else if (c == Color.GREY) {
			attacked.setStyle("-fx-fill: red; -fx-stroke: black; -fx-stroke-width: 1;");// red xtyphmeno ploio
			int i = 0;
			while (myship[i].gettype() != 2) {
				i++;
			} // xtyph8hke to myship[i]

			myship[i].settimeshit();
			myship[i].setuntouched();
			myship[i].sethit();
			int pointsearned = 250;
			if (myship[i].gettimeshit() == 4) {// na ksanado edo to 5 and den doyleyei
				myship[i].setsunken();
				pointsearned += 500;
			}
			return pointsearned;
		} else if (c == Color.ORANGE) {
			attacked.setStyle("-fx-fill: red; -fx-stroke: black; -fx-stroke-width: 1;");// red xtyphmeno ploio
			int i = 0;
			while (myship[i].gettype() != 3) {
				i++;
			} // xtyph8hke to myship[i]
			myship[i].settimeshit();
			myship[i].setuntouched();
			myship[i].sethit();
			int pointsearned = 100;
			if (myship[i].gettimeshit() == 3) {// na ksanado edo to 5 and den doyleyei
				myship[i].setsunken();
				pointsearned += 250;
			}
			return pointsearned;
		} else if (c == Color.YELLOW) {
			attacked.setStyle("-fx-fill: red; -fx-stroke: black; -fx-stroke-width: 1;");// red xtyphmeno ploio
			int i = 0;
			while (myship[i].gettype() != 4) {
				i++;
			} // xtyph8hke to myship[i]
			myship[i].settimeshit();
			myship[i].setuntouched();
			myship[i].sethit();
			int pointsearned = 100;
			if (myship[i].gettimeshit() == 3) {// na ksanado edo to 5 and den doyleyei
				myship[i].setsunken();
				pointsearned += 0;
			}
			return pointsearned;
		} else if (c == Color.GREEN) {
			attacked.setStyle("-fx-fill: red; -fx-stroke: black; -fx-stroke-width: 1;");// red xtyphmeno ploio
			int i = 0;
			while (myship[i].gettype() != 5) {
				i++;
			} // xtyph8hke to myship[i]
			myship[i].settimeshit();
			myship[i].setuntouched();
			myship[i].sethit();
			int pointsearned = 50;
			if (myship[i].gettimeshit() == 2) {// na ksanado edo to 5 and den doyleyei
				myship[i].setsunken();
				pointsearned += 0;
			}
			return pointsearned;
		} else if (c == Color.RED || c == Color.BLACK) {
			return 0;
		} else {
			System.out.println("egine la8os");
			return 0;
		}

	}

	public int myshotresultTYPE(GridPane enemyboard) {
//type 0 gia gia astoxh bolh
		Rectangle attacked = new Rectangle();
		int row = shotrow;
		int col = shotcol;
		attacked = (Rectangle) enemyboard.getChildren().get(21 + 10 * row + col);
		Color c = (Color) attacked.getFill();
		if (c == Color.CYAN) {
			return 0;
		} else if (c == Color.BLUE) {
			return 1;
		} else if (c == Color.GREY) {
			return 2;
		} else if (c == Color.ORANGE) {
			return 3;
		} else if (c == Color.YELLOW) {
			return 4;
		} else if (c == Color.GREEN) {
			return 5;
		} else if (c == Color.RED || c == Color.BLACK) {
// System.out.println("Exeis ksanarikei edo bre mpoumpouna ");
			return 0;
		} else {
			System.out.println("egine la8os");
			return 0;
		}

	}

	public int enemyshotresultTYPE(GridPane myboard) {
//type 0 gia gia astoxh bolh
		Rectangle attacked = new Rectangle();
		int row = shotrow;
		int col = shotcol;
		attacked = (Rectangle) myboard.getChildren().get(21 + 10 * row + col);
		Color c = (Color) attacked.getFill();
		if (c == Color.CYAN) {
			return 0;
		} else if (c == Color.BLUE) {
			return 1;
		} else if (c == Color.GREY) {
			return 2;
		} else if (c == Color.ORANGE) {
			return 3;
		} else if (c == Color.YELLOW) {
			return 4;
		} else if (c == Color.GREEN) {
			return 5;
		} else if (c == Color.RED || c == Color.BLACK) {
			// System.out.println("Exeis ksanarikei edo bre mpoumpouna ");
			return 0;
		} else {
			System.out.println("egine la8os");
			return 0;
		}

	}

}
