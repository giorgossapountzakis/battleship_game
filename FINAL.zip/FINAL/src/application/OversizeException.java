package application;

class OversizeException extends Exception {
}
