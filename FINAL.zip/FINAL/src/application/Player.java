package application;

class Player {
	private int points;
	public Ship ship[];
	private double successfull = 0;
	private double shotsnumber = 0;
	private boolean firsttime = true;

	public boolean getfirsttime() {
		return firsttime;
	}

	public void setfirsttime() {
		firsttime = false;
	}
	private boolean flag5 = true;

	public boolean getflag5() {
		return flag5;
	}

	public void setflag5() {
		flag5 = false;
	}
	public void setflag5true() {
		flag5 = true;
	}
	
	
	
	private int[][] lastfiveshots = { { -1, -1, 0 }, { -1, -1, 0 }, { -1, -1, 0 }, { -1, -1, 0 }, { -1, -1, 0 } };// isos
																													// 8elei
	// public edo
	// pinakas 5*3 grammes=teleytaies 5boles,sthles=shotrow,shotcol,shotresulttype
	// kato kato h teleytaia

	public int[][] getlastfiveshots() {
		return lastfiveshots;
	}

	public void setlastfiveshots(Shot shot, int type) {
		if (shotsnumber > 5) {// grammh 5=nea bolh,grammh 4=prohgoymenh grammh 5
			lastfiveshots[0][0] = lastfiveshots[1][0];
			lastfiveshots[0][1] = lastfiveshots[1][1];
			lastfiveshots[0][2] = lastfiveshots[1][2];
			lastfiveshots[1][0] = lastfiveshots[2][0];
			lastfiveshots[1][1] = lastfiveshots[2][1];
			lastfiveshots[1][2] = lastfiveshots[2][2];
			lastfiveshots[2][0] = lastfiveshots[3][0];
			lastfiveshots[2][1] = lastfiveshots[3][1];
			lastfiveshots[2][2] = lastfiveshots[3][2];
			lastfiveshots[3][0] = lastfiveshots[4][0];
			lastfiveshots[3][1] = lastfiveshots[4][1];
			lastfiveshots[3][2] = lastfiveshots[4][2];
			lastfiveshots[4][0] = shot.getshotrow();
			lastfiveshots[4][1] = shot.getshotcol();
			lastfiveshots[4][2] = type;
		} else if (shotsnumber == 1) {
			lastfiveshots[0][0] = shot.getshotrow();
			lastfiveshots[0][1] = shot.getshotcol();
			lastfiveshots[0][2] = type;
		} else if (shotsnumber == 2) {
			lastfiveshots[1][0] = shot.getshotrow();
			lastfiveshots[1][1] = shot.getshotcol();
			lastfiveshots[1][2] = type;
		} else if (shotsnumber == 3) {
			lastfiveshots[2][0] = shot.getshotrow();
			lastfiveshots[2][1] = shot.getshotcol();
			lastfiveshots[2][2] = type;
		} else if (shotsnumber == 4) {
			lastfiveshots[3][0] = shot.getshotrow();
			lastfiveshots[3][1] = shot.getshotcol();
			lastfiveshots[3][2] = type;
		} else if (shotsnumber == 5) {
			lastfiveshots[4][0] = shot.getshotrow();
			lastfiveshots[4][1] = shot.getshotcol();
			lastfiveshots[4][2] = type;
		}

	}

	public Player(Ship[] fleet) {
		ship = fleet;

	}

	public double getsuccessfull() {
		return successfull;
	}

	public void setsuccessfull() {
		successfull += 1;
	}

	public double getshotsnumber() {
		return shotsnumber;
	}

	public void setshotsnumber() {
		shotsnumber += 1;
	}

	public int getpoints() {
		return points;
	}

	public void setpoints(int x) {
		points += x;
	}

	public int aliveships() {
		int aliveshipscounter = 0;
		for (int i = 0; i < 5; i++) {
			if (ship[i].getsunken() == false) {
				aliveshipscounter++;
			}
		}
		return aliveshipscounter;
	}

	public int tactic(Start item,int[] array) {
		int rowcol=item.getSecondRandomNumber(0,99);
		for(int i=0;i<5;i++) {
			if(lastfiveshots[i][2]!=0) {
			int r=lastfiveshots[i][0];
			int c=lastfiveshots[i][1];
			if(r!=0 &&r!=9 &&c!=0&&c!=9) {
				//genikh periptosh
				if(array[20+10*r+c+1]!=10&&array[20+10*r+c+1]!=11)return rowcol=10*r+c+1;
				else if(array[20+10*r+c-1]!=10&&array[20+10*r+c-1]!=11)return rowcol=10*r+c-1;
				else if(array[20+10*(r+1)+c]!=10&&array[20+10*(r+1)+c]!=11)return rowcol=10*(r+1)+c;
				else if(array[20+10*(r-1)+c]!=10&&array[20+10*(r-1)+c]!=11)return rowcol=10*(r-1)+c;
				//else return rowcol;
				else continue;
			}
			else if(r==0 &&c!=0&&c!=9) {//pano pano row 8eseis 2-8
				if(array[20+10*r+c+1]!=10&&array[20+10*r+c+1]!=11)return rowcol=10*r+c+1;
				else if(array[20+10*r+c-1]!=10&&array[20+10*r+c-1]!=11)return rowcol=10*r+c-1;
				else if(array[20+10*(r+1)+c]!=10&&array[20+10*(r+1)+c]!=11)return rowcol=10*(r+1)+c;
				else continue;
			}
			else if(r==9 &&c!=0&&c!=9) {//kato kato row 8eseis 2-8
				if(array[20+10*r+c+1]!=10&&array[20+10*r+c+1]!=11)return rowcol=10*r+c+1;
				else if(array[20+10*r+c-1]!=10&&array[20+10*r+c-1]!=11)return rowcol=10*r+c-1;
				else if(array[20+10*(r-1)+c]!=10&&array[20+10*(r-1)+c]!=11)return rowcol=10*(r-1)+c;
				else continue;
			}
			else if(r!=0 &&r!=9 &&c==0) {//aristera 8eseis 2-8
				if(array[20+10*r+c+1]!=10&&array[20+10*r+c+1]!=11)return rowcol=10*r+c+1;
				else if(array[20+10*(r+1)+c]!=10&&array[20+10*(r+1)+c]!=11)return rowcol=10*(r+1)+c;
				else if(array[20+10*(r-1)+c]!=10&&array[20+10*(r-1)+c]!=11)return rowcol=10*(r-1)+c;
				else continue;
			}
			else if(r!=0 &&r!=9 &&c==9) {//deksia 8eseis 2-8
				if(array[20+10*r+c-1]!=10&&array[20+10*r+c-1]!=11)return rowcol=10*r+c-1;
				else if(array[20+10*(r+1)+c]!=10&&array[20+10*(r+1)+c]!=11)return rowcol=10*(r+1)+c;
				else if(array[20+10*(r-1)+c]!=10&&array[20+10*(r-1)+c]!=11)return rowcol=10*(r-1)+c;
				else continue;
			}
			else if(r==0&&c==0) {//pano aristera gonia
				if(array[20+10*r+c+1]!=10&&array[20+10*r+c+1]!=11)return rowcol=10*r+c+1;
				else if(array[20+10*(r+1)+c]!=10&&array[20+10*(r+1)+c]!=11)return rowcol=10*(r+1)+c;
				else continue;
			}
			else if(r==0&&c==9) {//pano deksia gonia
				if(array[20+10*r+c-1]!=10&&array[20+10*r+c-1]!=11)return rowcol=10*r+c-1;
				else if(array[20+10*(r+1)+c]!=10&&array[20+10*(r+1)+c]!=11)return rowcol=10*(r+1)+c;
				else continue;
			}
			else if(r==9&&c==0) {//kato aristera gonia
				if(array[20+10*r+c+1]!=10&&array[20+10*r+c+1]!=11)return rowcol=10*r+c+1;
				else if(array[20+10*(r-1)+c]!=10&&array[20+10*(r-1)+c]!=11)return rowcol=10*(r-1)+c;
				else continue;
			}
			else{//kato deksia gonia
				if(array[20+10*r+c-1]!=10&&array[20+10*r+c-1]!=11)return rowcol=10*r+c-1;
				else if(array[20+10*(r-1)+c]!=10&&array[20+10*(r-1)+c]!=11)return rowcol=10*(r-1)+c;
				else continue;
			}
			//break;
		}
	}	
		//an telika riksei sth tyxh na mhn riksei se hdh rigmeno
		int ro=rowcol/10;
		int co=rowcol%10;
		while(array[20+10*ro+co]==10) {rowcol=item.getSecondRandomNumber(0,99);ro=rowcol/10;co=rowcol%10;}
		return rowcol;
	}
	
	
	
}
