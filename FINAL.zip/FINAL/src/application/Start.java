package application;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

class Start {
	private int ID = -1;
	private boolean pressedload = false;
	

	public boolean getpressedload() {
		return pressedload;
	}

	public void setpressedload() {
		pressedload = true;
	}

	public void setID(int x) {
		ID = x;
	}

	public int getID() {
		return ID;
	}

	public int getRandomNumber(int min, int max) {
		return (int) ((Math.random() * (max - min)) + min);
	}
	public int getSecondRandomNumber(int min, int max) {
		return (int) ((Math.random() * (max - min)) + min);
	}

	public int[] mydeploy(GridPane myboard, Ship[] myship) {
		int[] helparray = new int[120];
		for (int j = 0; j < 120; j++)
			helparray[j] = 0;
		Rectangle[] firstchange = new Rectangle[19];
		int changecounter = 0;
		for (int s = 0; s < 5; s++) {
			int shiptype = myship[s].gettype();
			int shiprow = myship[s].getrow();
			int shipcol = myship[s].getcol();
			int shiporientation = myship[s].getorientation();
			switch (shiptype) {
			case (1):// 5koytakia
				if (shiporientation == 1) {
					helparray[20 + 10 * shiprow + shipcol] = 1;
					firstchange[changecounter] = (Rectangle) myboard.getChildren().get(21 + 10 * shiprow + shipcol);
					firstchange[changecounter].setStyle("-fx-fill: blue; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;
					helparray[20 + 10 * shiprow + shipcol + 1] = 1;
					firstchange[changecounter] = (Rectangle) myboard.getChildren().get(21 + 10 * shiprow + shipcol + 1);
					firstchange[changecounter].setStyle("-fx-fill: blue; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;
					helparray[20 + 10 * shiprow + shipcol + 2] = 1;
					firstchange[changecounter] = (Rectangle) myboard.getChildren().get(21 + 10 * shiprow + shipcol + 2);
					firstchange[changecounter].setStyle("-fx-fill: blue; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;
					helparray[20 + 10 * shiprow + shipcol + 3] = 1;
					firstchange[changecounter] = (Rectangle) myboard.getChildren().get(21 + 10 * shiprow + shipcol + 3);
					firstchange[changecounter].setStyle("-fx-fill: blue; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;
					helparray[20 + 10 * shiprow + shipcol + 4] = 1;
					firstchange[changecounter] = (Rectangle) myboard.getChildren().get(21 + 10 * shiprow + shipcol + 4);
					firstchange[changecounter].setStyle("-fx-fill: blue; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;

				} else {
					helparray[20 + 10 * (shiprow) + shipcol] = 1;
					firstchange[changecounter] = (Rectangle) myboard.getChildren().get(21 + 10 * (shiprow) + shipcol);
					firstchange[changecounter].setStyle("-fx-fill: blue; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;
					helparray[20 + 10 * (shiprow + 1) + shipcol] = 1;
					firstchange[changecounter] = (Rectangle) myboard.getChildren()
							.get(21 + 10 * (shiprow + 1) + shipcol);
					firstchange[changecounter].setStyle("-fx-fill: blue; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;
					helparray[20 + 10 * (shiprow + 2) + shipcol] = 1;
					firstchange[changecounter] = (Rectangle) myboard.getChildren()
							.get(21 + 10 * (shiprow + 2) + shipcol);
					firstchange[changecounter].setStyle("-fx-fill: blue; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;
					helparray[20 + 10 * (shiprow + 3) + shipcol] = 1;
					firstchange[changecounter] = (Rectangle) myboard.getChildren()
							.get(21 + 10 * (shiprow + 3) + shipcol);
					firstchange[changecounter].setStyle("-fx-fill: blue; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;
					helparray[20 + 10 * (shiprow + 4) + shipcol] = 1;
					firstchange[changecounter] = (Rectangle) myboard.getChildren()
							.get(21 + 10 * (shiprow + 4) + shipcol);
					firstchange[changecounter].setStyle("-fx-fill: blue; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;
				}
				break;
			case (2):
				// changecounter = 5;
				if (shiporientation == 1) {
					helparray[20 + 10 * shiprow + shipcol] = 2;
					firstchange[changecounter] = (Rectangle) myboard.getChildren().get(21 + 10 * shiprow + shipcol);
					firstchange[changecounter].setStyle("-fx-fill: grey; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;
					helparray[20 + 10 * shiprow + shipcol + 1] = 2;
					firstchange[changecounter] = (Rectangle) myboard.getChildren().get(21 + 10 * shiprow + shipcol + 1);
					firstchange[changecounter].setStyle("-fx-fill: grey; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;
					helparray[20 + 10 * shiprow + shipcol + 2] = 2;
					firstchange[changecounter] = (Rectangle) myboard.getChildren().get(21 + 10 * shiprow + shipcol + 2);
					firstchange[changecounter].setStyle("-fx-fill: grey; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;
					helparray[20 + 10 * shiprow + shipcol + 3] = 2;
					firstchange[changecounter] = (Rectangle) myboard.getChildren().get(21 + 10 * shiprow + shipcol + 3);
					firstchange[changecounter].setStyle("-fx-fill: grey; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;

				} else {
					helparray[20 + 10 * (shiprow) + shipcol] = 2;
					firstchange[changecounter] = (Rectangle) myboard.getChildren().get(21 + 10 * (shiprow) + shipcol);
					firstchange[changecounter].setStyle("-fx-fill: grey; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;
					helparray[20 + 10 * (shiprow + 1) + shipcol] = 2;
					firstchange[changecounter] = (Rectangle) myboard.getChildren()
							.get(21 + 10 * (shiprow + 1) + shipcol);
					firstchange[changecounter].setStyle("-fx-fill: grey; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;
					helparray[20 + 10 * (shiprow + 2) + shipcol] = 2;
					firstchange[changecounter] = (Rectangle) myboard.getChildren()
							.get(21 + 10 * (shiprow + 2) + shipcol);
					firstchange[changecounter].setStyle("-fx-fill: grey; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;
					helparray[20 + 10 * (shiprow + 3) + shipcol] = 2;
					firstchange[changecounter] = (Rectangle) myboard.getChildren()
							.get(21 + 10 * (shiprow + 3) + shipcol);
					firstchange[changecounter].setStyle("-fx-fill: grey; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;
				}
				break;
			case (3):
				// changecounter = 9;
				if (shiporientation == 1) {
					helparray[20 + 10 * shiprow + shipcol] = 3;
					firstchange[changecounter] = (Rectangle) myboard.getChildren().get(21 + 10 * shiprow + shipcol);
					firstchange[changecounter].setStyle("-fx-fill: orange; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;
					helparray[20 + 10 * shiprow + shipcol + 1] = 3;
					firstchange[changecounter] = (Rectangle) myboard.getChildren().get(21 + 10 * shiprow + shipcol + 1);
					firstchange[changecounter].setStyle("-fx-fill: orange; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;
					helparray[20 + 10 * shiprow + shipcol + 2] = 3;
					firstchange[changecounter] = (Rectangle) myboard.getChildren().get(21 + 10 * shiprow + shipcol + 2);
					firstchange[changecounter].setStyle("-fx-fill: orange; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;

				} else {
					helparray[20 + 10 * (shiprow) + shipcol] = 3;
					firstchange[changecounter] = (Rectangle) myboard.getChildren().get(21 + 10 * (shiprow) + shipcol);
					firstchange[changecounter].setStyle("-fx-fill: orange; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;
					helparray[20 + 10 * (shiprow + 1) + shipcol] = 3;
					firstchange[changecounter] = (Rectangle) myboard.getChildren()
							.get(21 + 10 * (shiprow + 1) + shipcol);
					firstchange[changecounter].setStyle("-fx-fill: orange; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;
					helparray[20 + 10 * (shiprow + 2) + shipcol] = 3;
					firstchange[changecounter] = (Rectangle) myboard.getChildren()
							.get(21 + 10 * (shiprow + 2) + shipcol);
					firstchange[changecounter].setStyle("-fx-fill: orange; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;
				}
				break;
			case (4):
				// changecounter = 12;
				if (shiporientation == 1) {
					helparray[20 + 10 * shiprow + shipcol] = 4;
					firstchange[changecounter] = (Rectangle) myboard.getChildren().get(21 + 10 * shiprow + shipcol);
					firstchange[changecounter].setStyle("-fx-fill: yellow; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;
					helparray[20 + 10 * shiprow + shipcol + 1] = 4;
					firstchange[changecounter] = (Rectangle) myboard.getChildren().get(21 + 10 * shiprow + shipcol + 1);
					firstchange[changecounter].setStyle("-fx-fill: yellow; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;
					helparray[20 + 10 * shiprow + shipcol + 2] = 4;
					firstchange[changecounter] = (Rectangle) myboard.getChildren().get(21 + 10 * shiprow + shipcol + 2);
					firstchange[changecounter].setStyle("-fx-fill: yellow; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;

				} else {
					helparray[20 + 10 * (shiprow) + shipcol] = 4;
					firstchange[changecounter] = (Rectangle) myboard.getChildren().get(21 + 10 * (shiprow) + shipcol);
					firstchange[changecounter].setStyle("-fx-fill: yellow; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;
					helparray[20 + 10 * (shiprow + 1) + shipcol] = 4;
					firstchange[changecounter] = (Rectangle) myboard.getChildren()
							.get(21 + 10 * (shiprow + 1) + shipcol);
					firstchange[changecounter].setStyle("-fx-fill: yellow; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;
					helparray[20 + 10 * (shiprow + 2) + shipcol] = 4;
					firstchange[changecounter] = (Rectangle) myboard.getChildren()
							.get(21 + 10 * (shiprow + 2) + shipcol);
					firstchange[changecounter].setStyle("-fx-fill: yellow; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;

				}
				break;
			case (5):
				// changecounter = 15;
				if (shiporientation == 1) {
					helparray[20 + 10 * shiprow + shipcol] = 5;
					firstchange[changecounter] = (Rectangle) myboard.getChildren().get(21 + 10 * shiprow + shipcol);
					firstchange[changecounter].setStyle("-fx-fill: green; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;
					helparray[20 + 10 * shiprow + shipcol + 1] = 5;
					firstchange[changecounter] = (Rectangle) myboard.getChildren().get(21 + 10 * shiprow + shipcol + 1);
					firstchange[changecounter].setStyle("-fx-fill: green; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;

				} else {
					helparray[20 + 10 * (shiprow) + shipcol] = 5;
					firstchange[changecounter] = (Rectangle) myboard.getChildren().get(21 + 10 * (shiprow) + shipcol);
					firstchange[changecounter].setStyle("-fx-fill: green; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;
					helparray[20 + 10 * (shiprow + 1) + shipcol] = 5;
					firstchange[changecounter] = (Rectangle) myboard.getChildren()
							.get(21 + 10 * (shiprow + 1) + shipcol);
					firstchange[changecounter].setStyle("-fx-fill: green; -fx-stroke: black; -fx-stroke-width: 1;");
					changecounter++;
				}
			}
		}

		return helparray;

	}

	public int[] enemydeploy(GridPane enemyboard, Ship[] enemyship) {
		int[] enehelparray = new int[120];
		for (int j = 0; j < 120; j++)
			enehelparray[j] = 0;
		Rectangle[] enefirstchange = new Rectangle[19];
		int enechangecounter = 0;
		for (int s = 0; s < 5; s++) {
			int eneshiptype = enemyship[s].gettype();
			int eneshiprow = enemyship[s].getrow();
			int eneshipcol = enemyship[s].getcol();
			int eneshiporientation = enemyship[s].getorientation();
			switch (eneshiptype) {
			case (1):// 5koytakia
				if (eneshiporientation == 1) {
					enehelparray[20 + 10 * eneshiprow + eneshipcol] = 1;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * eneshiprow + eneshipcol);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: blue; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;
					enehelparray[20 + 10 * eneshiprow + eneshipcol + 1] = 1;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * eneshiprow + eneshipcol + 1);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: blue; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;
					enehelparray[20 + 10 * eneshiprow + eneshipcol + 2] = 1;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * eneshiprow + eneshipcol + 2);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: blue; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;
					enehelparray[20 + 10 * eneshiprow + eneshipcol + 3] = 1;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * eneshiprow + eneshipcol + 3);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: blue; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;
					enehelparray[20 + 10 * eneshiprow + eneshipcol + 4] = 1;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * eneshiprow + eneshipcol + 4);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: blue; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;

				} else {
					enehelparray[20 + 10 * (eneshiprow) + eneshipcol] = 1;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * (eneshiprow) + eneshipcol);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: blue; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;
					enehelparray[20 + 10 * (eneshiprow + 1) + eneshipcol] = 1;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * (eneshiprow + 1) + eneshipcol);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: blue; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;
					enehelparray[20 + 10 * (eneshiprow + 2) + eneshipcol] = 1;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * (eneshiprow + 2) + eneshipcol);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: blue; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;
					enehelparray[20 + 10 * (eneshiprow + 3) + eneshipcol] = 1;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * (eneshiprow + 3) + eneshipcol);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: blue; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;
					enehelparray[20 + 10 * (eneshiprow + 4) + eneshipcol] = 1;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * (eneshiprow + 4) + eneshipcol);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: blue; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;
				}
				break;
			case (2):
				// enechangecounter = 5;
				if (eneshiporientation == 1) {
					enehelparray[20 + 10 * eneshiprow + eneshipcol] = 2;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * eneshiprow + eneshipcol);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: grey; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;
					enehelparray[20 + 10 * eneshiprow + eneshipcol + 1] = 2;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * eneshiprow + eneshipcol + 1);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: grey; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;
					enehelparray[20 + 10 * eneshiprow + eneshipcol + 2] = 2;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * eneshiprow + eneshipcol + 2);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: grey; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;
					enehelparray[20 + 10 * eneshiprow + eneshipcol + 3] = 2;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * eneshiprow + eneshipcol + 3);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: grey; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;
				} else {
					enehelparray[20 + 10 * (eneshiprow) + eneshipcol] = 2;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * (eneshiprow) + eneshipcol);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: grey; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;
					enehelparray[20 + 10 * (eneshiprow + 1) + eneshipcol] = 2;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * (eneshiprow + 1) + eneshipcol);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: grey; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;
					enehelparray[20 + 10 * (eneshiprow + 2) + eneshipcol] = 2;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * (eneshiprow + 2) + eneshipcol);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: grey; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;
					enehelparray[20 + 10 * (eneshiprow + 3) + eneshipcol] = 2;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * (eneshiprow + 3) + eneshipcol);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: grey; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;
				}
				break;
			case (3):
				// enechangecounter = 9;
				if (eneshiporientation == 1) {
					enehelparray[20 + 10 * eneshiprow + eneshipcol] = 3;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * eneshiprow + eneshipcol);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: orange; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;
					enehelparray[20 + 10 * eneshiprow + eneshipcol + 1] = 3;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * eneshiprow + eneshipcol + 1);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: orange; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;
					enehelparray[20 + 10 * eneshiprow + eneshipcol + 2] = 3;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * eneshiprow + eneshipcol + 2);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: orange; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;
				} else {
					enehelparray[20 + 10 * (eneshiprow) + eneshipcol] = 3;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * (eneshiprow) + eneshipcol);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: orange; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;
					enehelparray[20 + 10 * (eneshiprow + 1) + eneshipcol] = 3;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * (eneshiprow + 1) + eneshipcol);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: orange; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;
					enehelparray[20 + 10 * (eneshiprow + 2) + eneshipcol] = 3;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * (eneshiprow + 2) + eneshipcol);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: orange; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;
				}
				break;
			case (4):
				// enechangecounter = 12;
				if (eneshiporientation == 1) {
					enehelparray[20 + 10 * eneshiprow + eneshipcol] = 4;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * eneshiprow + eneshipcol);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: yellow; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;
					enehelparray[20 + 10 * eneshiprow + eneshipcol + 1] = 4;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * eneshiprow + eneshipcol + 1);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: yellow; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;
					enehelparray[20 + 10 * eneshiprow + eneshipcol + 2] = 4;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * eneshiprow + eneshipcol + 2);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: yellow; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;
				} else {
					enehelparray[20 + 10 * (eneshiprow) + eneshipcol] = 4;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * (eneshiprow) + eneshipcol);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: yellow; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;
					enehelparray[20 + 10 * (eneshiprow + 1) + eneshipcol] = 4;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * (eneshiprow + 1) + eneshipcol);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: yellow; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;
					enehelparray[20 + 10 * (eneshiprow + 2) + eneshipcol] = 4;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * (eneshiprow + 2) + eneshipcol);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: yellow; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;
				}
				break;
			case (5):
				// enechangecounter = 15;
				if (eneshiporientation == 1) {
					enehelparray[20 + 10 * eneshiprow + eneshipcol] = 5;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * eneshiprow + eneshipcol);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: green; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;
					enehelparray[20 + 10 * eneshiprow + eneshipcol + 1] = 5;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * eneshiprow + eneshipcol + 1);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: green; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;
				} else {
					enehelparray[20 + 10 * (eneshiprow) + eneshipcol] = 5;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * (eneshiprow) + eneshipcol);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: green; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;
					enehelparray[20 + 10 * (eneshiprow + 1) + eneshipcol] = 5;
					enefirstchange[enechangecounter] = (Rectangle) enemyboard.getChildren()
							.get(21 + 10 * (eneshiprow + 1) + eneshipcol);
					enefirstchange[enechangecounter]
							.setStyle("-fx-fill: green; -fx-stroke: black; -fx-stroke-width: 1;");
					enechangecounter++;
				}
			}
		}
		return enehelparray;
	}

	public void createmyboard(GridPane myboard) {
		myboard.add(new Text(" "), 0, 0);
		Text[] text = new Text[11];
		for (int i = 0; i < 10; i++) {
			text[i] = new Text(String.valueOf(i));
			text[i].setTextAlignment(TextAlignment.CENTER);
			myboard.add(text[i], 0, i + 1);
		}
		for (int i = 0; i < 10; i++) {
			text[i] = new Text(String.valueOf(i));
			text[i].setTextAlignment(TextAlignment.CENTER);
			myboard.add(text[i], i + 1, 0);
		}
		Rectangle[][] myrect = new Rectangle[11][11];
		for (int i = 1; i < 11; i++) {
			for (int j = 1; j < 11; j++) {
				myrect[i][j] = new Rectangle(20, 20, 20, 20);
				myrect[i][j].setStyle("-fx-fill: CYAN; -fx-stroke: black; -fx-stroke-width: 1;");
				myboard.add(myrect[i][j], j, i);// edo nomizo anapoda gia to gridpane
			}
		}

	}

	public void createmyshotboard(GridPane myshotboard) {
		myshotboard.add(new Text(" "), 0, 0);
		Text[] myshottext = new Text[11];
		for (int i = 0; i < 10; i++) {
			myshottext[i] = new Text(String.valueOf(i));
			myshottext[i].setTextAlignment(TextAlignment.CENTER);
			myshotboard.add(myshottext[i], 0, i + 1);
		}
		for (int i = 0; i < 10; i++) {
			myshottext[i] = new Text(String.valueOf(i));
			myshottext[i].setTextAlignment(TextAlignment.CENTER);
			myshotboard.add(myshottext[i], i + 1, 0);

		}
		Rectangle[][] myshotrect = new Rectangle[11][11];
		for (int i = 1; i < 11; i++) {
			for (int j = 1; j < 11; j++) {
				myshotrect[i][j] = new Rectangle(20, 20, 20, 20);
				myshotrect[i][j].setStyle("-fx-fill: Cyan; -fx-stroke: black; -fx-stroke-width: 1;");
				myshotboard.add(myshotrect[i][j], j, i);// edo nomizo anapoda gia to gridpane
			}
		}

	}

	public void createenemyboard(GridPane enemyboard) {
		enemyboard.add(new Text(" "), 0, 0);
		Text[] enetext = new Text[11];
		for (int i = 0; i < 10; i++) {
			enetext[i] = new Text(String.valueOf(i));
			enetext[i].setTextAlignment(TextAlignment.CENTER);
			enemyboard.add(enetext[i], 0, i + 1);
		}
		for (int i = 0; i < 10; i++) {
			enetext[i] = new Text(String.valueOf(i));
			enetext[i].setTextAlignment(TextAlignment.CENTER);
			enemyboard.add(enetext[i], i + 1, 0);

		}
		Rectangle[][] enemyrect = new Rectangle[11][11];
		for (int i = 1; i < 11; i++) {
			for (int j = 1; j < 11; j++) {
				enemyrect[i][j] = new Rectangle(20, 20, 20, 20);
				enemyrect[i][j].setStyle("-fx-fill: Cyan; -fx-stroke: black; -fx-stroke-width: 1;");
				enemyboard.add(enemyrect[i][j], j, i);// edo nomizo anapoda gia to gridpane
			}
		}
	}

	public Ship[] readmyships(File f, FileReader fr, Ship[] myship) throws IOException {
		BufferedReader br = new BufferedReader(fr); // Creation of BufferedReader object
		int c = 0;
		int counter = 0, shipcounter = 0;
		int[] use = new int[4];
		while ((c = br.read()) != -1) {
			char character = (char) c;
			int x = Character.getNumericValue(character);
			if (c != ',' && c != '\n' && x >= 0) {
				use[counter] = x;
				counter++;
			}
			if (counter == 4) {
				myship[shipcounter] = new Ship(use[0], use[1], use[2], use[3]);
				shipcounter++;
				counter = 0;
			}
		}
		// System.out.println(myship[4]);
		return myship;

	}

	public Ship[] readenemyships(File enef, FileReader enefr, Ship[] enemyship) throws IOException {
		BufferedReader enebr = new BufferedReader(enefr); // Creation of BufferedReader object
		int enec = 0;
		int enecounter = 0, eneshipcounter = 0;
		int[] eneuse = new int[4];

		while ((enec = enebr.read()) != -1) {
			char enecharacter = (char) enec;
			int enex = Character.getNumericValue(enecharacter);
			if (enec != ',' && enec != '\n' && enex >= 0) {
				// System.out.println(x);
				eneuse[enecounter] = enex;
				enecounter++;
			}
			if (enecounter == 4) {
				enemyship[eneshipcounter] = new Ship(eneuse[0], eneuse[1], eneuse[2], eneuse[3]);
				eneshipcounter++;
				enecounter = 0;
			}
		}
		return enemyship;
	}

	public void change(GridPane grid, int textnum, int number) {
		VBox changevbox = new VBox();
		changevbox = (VBox) grid.getChildren().get(textnum);
		Text changetext = new Text();
		changetext = (Text) changevbox.getChildren().get(0);
		changetext.setText(String.valueOf(number));
	}

	public void change(GridPane grid, int textnum, double number) {
		VBox changevbox = new VBox();
		changevbox = (VBox) grid.getChildren().get(textnum);
		Text changetext = new Text();
		changetext = (Text) changevbox.getChildren().get(0);
		changetext.setText(String.format("%.2f", number));
	}

	public void change(GridPane grid, int textnum, String S) {
		VBox changevbox = new VBox();
		changevbox = (VBox) grid.getChildren().get(textnum);
		Text changetext = new Text();
		changetext = (Text) changevbox.getChildren().get(0);
		changetext.setText(S);
	}

	public void finish(Player me, Player computer) {
		System.out.println("GAME OVER");// ayto 8a to embanizei h se kapoio koytaki h se
		// para8yro
		Stage popupstage = new Stage();
		popupstage.setTitle("RESULT");
		BorderPane popuppane = new BorderPane();
		HBox insertHBox = new HBox();
		if (computer.aliveships() == 0 || me.getpoints() >= computer.getpoints()) {
			Text text0 = new Text("YOU WON !!!");
			text0.setFont(Font.font("Verdana", 30));
			text0.setFill(Color.ORANGE);
			insertHBox.getChildren().add(text0);
			popuppane.setCenter(insertHBox);
		} else if (me.aliveships() == 0 || me.getpoints() < computer.getpoints()) {
			Text text0 = new Text("COMPUTER WON !!!");
			text0.setFont(Font.font("Verdana", 30));
			text0.setFill(Color.RED);
			insertHBox.getChildren().add(text0);
			popuppane.setCenter(insertHBox);
		}
		Scene popupscene = new Scene(popuppane, 500, 300);
		popupstage.setScene(popupscene);
		popupstage.show();


	}

	public void typecheck(Ship[] ships) throws InvalidCountExeception {
		for (int i = 0; i < 5; i++) {
			for (int j = i + 1; j < 5; j++) {
				if (ships[j].gettype() == ships[i].gettype())
					throw new InvalidCountExeception();
			}
		}
	}

	public void sameplacecheck(int[] array) throws OverlapTilesException {
		int counter = 0;
		for (int i = 20; i < 120; i++) {// 21-121 an ksekinaei ap to 1
			if (array[i] != 0 && array[i]!=10) {
				counter++;
			}
		}
		if (counter < 17) {// 17 na to do
			counter = 0;
			//System.out.println("OverlapTilesException");
			throw new OverlapTilesException();

		}
	}

	public void tancheck(int[] array) throws AdjacentTilesException {

		for (int i = 20; i < 120; i++) {
			if (array[i] != 0) {
				if (i <= 29) {
					if (array[i + 1] != 0 && (i + 1) % 10 != 0) {
						if (array[i + 1] != array[i])
							throw new AdjacentTilesException();
					}
					if (array[i - 1] != 0 && (i) % 10 != 0 && i != 20) {
						if (array[i - 1] != array[i])
							throw new AdjacentTilesException();
					}
					if (array[i + 10] != 0) {
						if (array[i + 10] != array[i])
							throw new AdjacentTilesException();
					}
				} else if (i >= 110) {
					if (array[i + 1] != 0 && (i + 1) % 10 != 0 && i != 119) {
						if (array[i + 1] != array[i])
							throw new AdjacentTilesException();
					}
					if (array[i - 1] != 0 && (i) % 10 != 0) {
						if (array[i - 1] != array[i])
							throw new AdjacentTilesException();
					}
					if (array[i - 10] != 0) {
						if (array[i - 10] != array[i])
							throw new AdjacentTilesException();
					}
				} else {
					if (array[i + 1] != 0 && (i + 1) % 10 != 0) {
						if (array[i + 1] != array[i])
							throw new AdjacentTilesException();
					}
					if (array[i - 1] != 0 && (i) % 10 != 0) {
						if (array[i - 1] != array[i])
							throw new AdjacentTilesException();
					}
					if (array[i + 10] != 0) {
						if (array[i + 10] != array[i])
							throw new AdjacentTilesException();
					}
					if (array[i - 10] != 0) {
						if (array[i - 10] != array[i])
							throw new AdjacentTilesException();
					}
				}
			}
		}
	}

}
