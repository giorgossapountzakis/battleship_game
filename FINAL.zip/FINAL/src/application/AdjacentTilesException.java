package application;

class AdjacentTilesException extends Exception {
}
