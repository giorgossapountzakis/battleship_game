/*
 * This Class organizes all methods for the ships of the game.
 * @author Giorgos Sapountzakis
 * @version 1.0
 * @since 2020-02-8
 * */


package application;

class Ship {
	private int type;
	private int row;
	private int col;
	private int orientation;
	private boolean untouched = true;
	private boolean hit = false;
	private boolean sunken = false;
	private int timeshit = 0;

/*
 *This is the constructor method, it builds the item ship
 *with the use of four arithemetic parameters.
 *
 *@param type this ship's type , ranging from one to five
 *@param row  the row of the ship's first rectangle on the board , ranging from zero to nine
 *@param col  the column of the ship's first rectangle on the board , ranging from zero to nine
 *@param orientation  the orientation of the ship , ranging from one to two
 * */
	public Ship(int type, int row, int col, int orientation) {
		this.type = type;
		this.row = row;
		this.col = col;
		this.orientation = orientation;
	}

/*
 * This function returns the value of the private int timeshit
 * @return timeshit
 * */
	public int gettimeshit() {
		return timeshit;
	}

	/*
	 * This function returns the value of the private int type
	 * @return type
	 * */	
	public int gettype() {
		return type;
	}

	/*
	 * This function returns the value of the private int row
	 * @return row
	 * */
	public int getrow() {
		return row;
	}

	/*
	 * This function returns the value of the private int col
	 * @return col
	 * */
	public int getcol() {
		return col;
	}

	/*
	 * This function returns the value of the private int orientation
	 * @return orientation
	 * */
	public int getorientation() {
		return orientation;
	}

	/*
	 * This function returns the value of the private boolean untouched
	 * @return untouched
	 * */
	public boolean getuntouched() {
		return untouched;
	}

	/*
	 * This function returns the value of the private boolean hit
	 * @return hit
	 * */	
	public boolean gethit() {
		return hit;
	}

	/*
	 * This function returns the value of the private boolean sunken
	 * @return sunken
	 * */
	public boolean getsunken() {
		return sunken;
	}

	/*
	 * This function sets the value of the private boolean untouched to false
	 * */
	public void setuntouched() {
		untouched = false;
	}
	/*
	 * This function sets the value of the private boolean hit to true
	 * */
	public void sethit() {
		hit = true;
	}
	/*
	 * This function sets the value of the private boolean sunken to true
	 * */
	public void setsunken() {
		sunken = true;
	}

	/*
	 * This function increases the value of the private int timeshit by one
	 * */
	public void settimeshit() {
		timeshit += 1;
	}

	/*This function checks if there is a ship out of the table bounds
	 * @throws OversizeException
	 * */
	public void isoutoftable() throws OversizeException {
														// bazo ploia deksia kai pros ta kato ,// an einai ola kala gyrnaei false
		//boolean result = false;
		if (col > 9 || col < 0 || row < 0 || row > 9)
			throw new OversizeException();
		switch (type) {
		case (1):
			if (orientation == 1) {
				if (col <= 5)
					{}//result = false;
				else
					throw new OversizeException();
			} else if (orientation == 2) {
				if (row <= 5)
				{}//result = false;
				else
					throw new OversizeException();
			}
			break;
		case (2):
			if (orientation == 1) {
				if (col <= 6)
				{}//result = false;
				else
					throw new OversizeException();
			} else if (orientation == 2) {
				if (row <= 6)
				{}//result = false;
				else
					throw new OversizeException();
			}
			break;
		case (3):
			if (orientation == 1) {
				if (col <= 7)
				{}//result = false;
				else
					throw new OversizeException();
			} else if (orientation == 2) {
				if (row <= 7)
				{}//result = false;
				else
					throw new OversizeException();
			}
			break;
		case (4):
			if (orientation == 1) {
				if (col <= 7)
				{}//result = false;
				else
					throw new OversizeException();
			} else if (orientation == 2) {
				if (row <= 7)
				{}//result = false;
				else
					throw new OversizeException();
			}
			break;
		case (5):
			if (orientation == 1) {
				if (col <= 8)
				{}//result = false;
				else
					throw new OversizeException();
			} else if (orientation == 2) {
				if (row <= 8)
				{}//result = false;
				else
					throw new OversizeException();
			}
			break;
		}
		//return result;
	}

}
