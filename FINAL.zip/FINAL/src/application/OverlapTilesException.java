package application;

class OverlapTilesException extends Exception {
}
